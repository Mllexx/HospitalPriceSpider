create function sp_get_billdthru(billfreq character varying, cycledate timestamp without time zone)
    returns TABLE(startdate date, billdthru timestamp without time zone)
    language plpgsql
as
$$
-- SPACER -- 
BEGIN
  IF extract(day from cycledate) <= 28 THEN
  	return query
 SELECT
	CAST(B.ENDDATE AS DATE) AS STARTDATE,
	CASE
		WHEN billfreq = 'ANL' THEN  ( (cycledate::date + INTERVAL'12 month')::date - INTERVAL'1 day' )  
		WHEN billfreq = '6MO' THEN  ( (cycledate::date + INTERVAL'6 month')::date - INTERVAL'1 day' ) 
		WHEN billfreq = '3MO' THEN  ( (cycledate::date + INTERVAL'3 month')::date - INTERVAL'1 day' ) 
		WHEN billfreq = '2MO' THEN  ( (cycledate::date + INTERVAL'2 month')::date - INTERVAL'1 day' )
		ELSE ( (cycledate::date + INTERVAL'1 month')::date - INTERVAL'1 day' )
	 END as BILLDTHRU
	FROM BILLCYCLE B
	where enddate=cycledate;
  ELSE
  return query
	SELECT
	CAST(B.ENDDATE AS DATE) AS STARTDATE,
	CASE
		WHEN billfreq = 'ANL' THEN  ( ((extract(year from cycledate::date) || '-' || extract(month from cycledate::date) || '-28')::date + INTERVAL'12 month')::date - INTERVAL'1 day' )
		WHEN billfreq = '6MO' THEN  ( ((extract(year from cycledate::date) || '-' || extract(month from cycledate::date) || '-28')::date + INTERVAL'6 month')::date - INTERVAL'1 day' )
		WHEN billfreq = '3MO' THEN  ( ((extract(year from cycledate::date) || '-' || extract(month from cycledate::date) || '-28')::date + INTERVAL'3 month')::date - INTERVAL'1 day' )
		WHEN billfreq = '2MO' THEN  ( ((extract(year from cycledate::date) || '-' || extract(month from cycledate::date) || '-28')::date + INTERVAL'2 month')::date - INTERVAL'1 day' )
		ELSE ( ((extract(year from cycledate::date) || '-' || extract(month from cycledate::date) || '-28')::date + INTERVAL'1 month')::date - INTERVAL'1 day' )
	 END as BILLDTHRU
	FROM BILLCYCLE B
	where enddate=(extract(year from cycledate::date) || '-' || extract(month from cycledate::date) || '-28')::date;
END IF;
  
END;
$$;

alter function sp_get_billdthru(varchar, timestamp) owner to postgres;

