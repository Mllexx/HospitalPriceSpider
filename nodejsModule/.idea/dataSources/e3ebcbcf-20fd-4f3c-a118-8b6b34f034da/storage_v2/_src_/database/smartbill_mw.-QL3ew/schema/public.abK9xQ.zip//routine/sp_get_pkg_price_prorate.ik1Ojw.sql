create function sp_get_pkg_price_prorate(fr integer, pkgid integer, dp integer)
    returns TABLE(pkgname character varying, franch integer, pkgcode character varying, packages integer, pkgtype integer, amt numeric, xtraamt numeric, tax numeric, xtratax numeric, amtwthtax numeric, xtraamtwthtax numeric)
    language sql
as
$$
SELECT
P.DESCRIP as pkgname,
f.FRANCH,
p.PKGCODE,
p.PACKAGES,
P.PKGTYPE,
ROUND(ROUND((SUM(distinct fd.DISTNRM)*dp)::numeric,2),0) as amt
,ROUND(ROUND((SUM(distinct fd.DISTXTRA)*dp)::numeric,2),0) as xtraamt
,SUM(ROUND((((ftd.TAXRATE/100) *fd.DISTNRM*dp))::numeric,0)) as tax
,SUM(ROUND( (((ftd.TAXRATE/100)*fd.DISTXTRA*dp))::numeric,0)) as xtratax
,ROUND(ROUND((SUM(distinct fd.DISTNRM)*dp)::numeric,2),0)+SUM(ROUND( (((ftd.TAXRATE/100) *fd.DISTNRM*dp))::numeric,0)) as AMTWTHTAX
,ROUND(ROUND((SUM(distinct fd.DISTXTRA)*dp)::numeric,2),0)+SUM(ROUND( (((ftd.TAXRATE/100) *fd.DISTXTRA*dp))::numeric,0)) as XTRAAMTWTHTAX
FROM PACKAGES P
JOIN PACKSERV PS ON P.PACKAGES=PS.PACKAGES
JOIN SERVICES S ON PS.SERVICES = S.SERVICES AND S.ACTIVEITEM=1
JOIN FRRATES F ON F.PACKAGES=p.PACKAGES AND F.RATEEND::date > CURRENT_DATE AND F.ACTIVEITEM=1
JOIN FRDISTR FD ON FD.SERVICES = S.SERVICES AND FD.FRRATES=F.FRRATES
FULL JOIN FRTAXGRPDETAIL FTD ON FD.FRTAXGRP = FTD.FRTAXGRP AND FTD.ISACTIVE=1
WHERE p.ACTIVEITEM=1
and f.FRANCH= fr
and p.PACKAGES= pkgid
group by p.PKGCODE,p.PACKAGES,f.franch,P.DESCRIP,P.PKGTYPE
ORDER BY P.DESCRIP
$$;

alter function sp_get_pkg_price_prorate(integer, integer, integer) owner to postgres;

