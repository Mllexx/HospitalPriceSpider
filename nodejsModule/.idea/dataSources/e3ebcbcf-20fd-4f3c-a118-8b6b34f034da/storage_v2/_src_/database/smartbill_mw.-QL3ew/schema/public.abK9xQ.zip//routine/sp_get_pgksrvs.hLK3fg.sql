create function sp_get_pgksrvs(pkgid integer, frid integer)
    returns TABLE(packages integer, pkgname character varying, pkgcode character varying, pkgtype integer, servicecode character varying, servtype integer, services integer, srvname character varying, srvamt numeric, srvamtxtra numeric, frtaxgrp integer)
    language sql
as
$$
SELECT
p.PACKAGES,
p.DESCRIP as PKGNAME,
p.PKGCODE,
p.PKGTYPE,
S.SERVICECODE,
S.SERVTYPE,
S.SERVICES
,S.DESCRIPTION as SRVNAME
,fd.DISTNRM AS SRVAMT
,fd.DISTXTRA AS SRVAMTXTRA 
,fd.FRTAXGRP
FROM PACKAGES P 
JOIN PACKSERV PS ON P.PACKAGES=PS.PACKAGES
JOIN SERVICES S ON PS.SERVICES = S.SERVICES AND S.ACTIVEITEM=1
JOIN FRRATES F ON F.PACKAGES=p.PACKAGES AND F.RATEEND > CAST(CURRENT_TIMESTAMP AS DATE) AND F.ACTIVEITEM=1 AND f.FRANCH = @frid
JOIN FRDISTR FD ON FD.SERVICES = S.SERVICES AND FD.FRRATES=F.FRRATES
FULL JOIN FRTAXGRPDETAIL FTD ON FD.FRTAXGRP = FTD.FRTAXGRP AND FTD.ISACTIVE=1
WHERE p.ACTIVEITEM=1
AND P.PACKAGES = pkgid

$$;

alter function sp_get_pgksrvs(integer, integer) owner to postgres;

