create function sp_get_curr_sub_pkgs_all(subid integer)
    returns TABLE(subpkg integer, subs integer, pkgname character varying, franch integer, pkgcode character varying, packages integer, pkgtype integer, amt numeric, xtraamt numeric, tax numeric, xtratax numeric, amtwthtax numeric, xtraamtwthtax numeric, startdate date, enddate date, bldthrudate date, prepaybucket integer)
    language sql
as
$$
SELECT
sp.subpkg,
sb.subs,
P.DESCRIP as pkgname,
f.FRANCH,
p.PKGCODE,
p.PACKAGES,
p.PKGTYPE,
SUM(distinct fd.DISTNRM) as amt
,SUM(distinct fd.DISTXTRA) as xtraamt
,round(SUM(((ftd.TAXRATE/100) *fd.DISTNRM))::numeric,0) as tax
,round(SUM(((ftd.TAXRATE/100)*fd.DISTXTRA))::numeric,0) as xtratax
,( (SUM(distinct fd.DISTNRM)+ROUND(SUM(((ftd.TAXRATE/100) *fd.DISTNRM))::numeric,0)) ) as AMTWTHTAX
,((SUM(distinct fd.DISTXTRA)+ROUND(SUM(((ftd.TAXRATE/100) *fd.DISTXTRA))::numeric,0)) ) as XTRAAMTWTHTAX,
SP.STARTDATE::date,
SP.ENDDATE::date,
Sp.BLDTHRUDATE::date,
Sp.PREPAYBUCKET
FROM SUBS sb
JOIN SUBPKG SP ON sb.SUBS=SP.SUBS AND SP.ENDDATE::date >= CURRENT_DATE
JOIN PACKAGES P ON  SP.PACKAGE = P.PACKAGES
JOIN PACKSERV PS ON P.PACKAGES=PS.PACKAGES
JOIN SERVICES S ON PS.SERVICES = S.SERVICES AND S.ACTIVEITEM=1
JOIN FRRATES F ON F.PACKAGES=p.PACKAGES AND F.RATEEND::date > CURRENT_DATE AND F.ACTIVEITEM=1 AND f.FRANCH = sb.FRANCH
JOIN FRDISTR FD ON FD.SERVICES = S.SERVICES AND FD.FRRATES=F.FRRATES
FULL JOIN FRTAXGRPDETAIL FTD ON FD.FRTAXGRP = FTD.FRTAXGRP AND FTD.ISACTIVE=1
WHERE p.ACTIVEITEM=1
AND sb.subs= subid
group by p.PKGCODE,p.PACKAGES,f.franch,P.DESCRIP,sb.SUBS,SP.SUBPKG,SP.STARTDATE,SP.ENDDATE,Sp.BLDTHRUDATE,Sp.PREPAYBUCKET,p.PKGTYPE
ORDER BY sb.SUBS

$$;

alter function sp_get_curr_sub_pkgs_all(integer) owner to postgres;

