create function sp_get_bcyclesubs(bctemplate integer)
    returns TABLE(subs integer, bcktbal double precision, billedthru date, isprepay integer, franch integer, bctemplate integer)
    language sql
as
$$
SELECT 
S.SUBS,
spb.AMOUNT as BCKTBAL,
CAST(s.BILLEDTHRU AS DATE) as BILLEDTHRU,
COALESCE(S.ISPREPAY,1) as ISPREPAY,
s.FRANCH,
S.BCTEMPLATE
FROM SUBS S
JOIN SUBPKG SP ON S.SUBS = SP.SUBS
JOIN subsprepaybucket spb ON S.SUBS=spb.SUBS AND spb.PREPAYBUCKET = 940 AND spb.ISACTIVE=1
WHERE bctemplate = bctemplate
AND SP.enddate::date > CURRENT_DATE
and SP.startdate::date <= CURRENT_DATE
order by s.subs
$$;

alter function sp_get_bcyclesubs(integer) owner to postgres;

