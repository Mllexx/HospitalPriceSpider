create function sp_get_invoicetx(subid integer, billcycle integer)
    returns TABLE(subs integer, amt double precision, descrip character varying, credit integer, smry integer)
    language sql
as
$$
SELECT 
t.SUBS
,t.AMT
,t.DESCRIP
,COALESCE(t.QTYFROM,1) as CREDIT
,0 as SMRY
FROM TRANS t
WHERE t.SUBS=subid AND t.BILLCYCLE=billcycle
UNION
select
tr.SUBS, 
SUM(TAXAMT) as taxamt
,t.TAXNAME
,0 as CREDIT
,1 as SMRY
from TAXAMTDETAIL a 
join TAX t ON a.TAX=t.TAX and t.ACTIVEITEM=1
join trans tr on a.TABLEKEY=tr.trans and a.TABLEID=74
where tr.SUBS = subid and tr.BILLCYCLE = billcycle
GROUP BY tr.SUBS,a.TAX, t.TAXCODE,t.TAXNAME
order by smry,credit asc
$$;

alter function sp_get_invoicetx(integer, integer) owner to postgres;

