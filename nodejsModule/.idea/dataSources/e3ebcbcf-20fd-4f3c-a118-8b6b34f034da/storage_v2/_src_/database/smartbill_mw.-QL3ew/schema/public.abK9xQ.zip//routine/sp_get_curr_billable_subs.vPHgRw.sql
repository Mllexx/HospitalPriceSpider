create function sp_get_curr_billable_subs(bctemplate integer)
    returns TABLE(subpkg integer, subs integer, franch integer, taxexempt integer, bctemplate integer, isprepay integer, billfreq integer, pkgtype integer, bldthrudate date, package integer, prepaybucket integer, frrates integer, startdate date, enddate date, bcktbal double precision, qty integer)
    language sql
as
$$
SELECT 
sp.SUBPKG,
S.SUBS,
s.FRANCH,
COALESCE(S.TAXEXEMPT,0) as TAXEXEMPT,
S.BCTEMPLATE,
COALESCE(S.ISPREPAY,1) as ISPREPAY,
S.BILLFREQ,
Sp.PKGTYPE,
SP.BLDTHRUDATE::date,
SP.PACKAGE,
Sp.PREPAYBUCKET,
SPA.FRRATES,
SPA.STARTDATE::date,
spa.ENDDATE::date,
spb.AMOUNT as BCKTBAL,
SPQ.QTY
FROM SUBS S
JOIN SUBPKG SP ON S.SUBS = SP.SUBS
JOIN SUBPKGAMT SPA ON SP.SUBPKG = SPA.SUBPKG AND CAST(SPA.ENDDATE as DATE) >= CAST(CURRENT_TIMESTAMP AS DATE)
JOIN SUBPKGQTY SPQ ON SP.SUBPKG = SPQ.SUBPKG AND SPQ.ENDDATE > CAST(CURRENT_TIMESTAMP AS DATE)
JOIN subsprepaybucket spb ON S.SUBS=spb.SUBS AND spb.PREPAYBUCKET = sp.PREPAYBUCKET AND spb.ISACTIVE=1
WHERE 
SP.enddate::date > CURRENT_DATE
and SP.startdate::date <= CURRENT_DATE
AND bctemplate = bctemplate
$$;

alter function sp_get_curr_billable_subs(integer) owner to postgres;

