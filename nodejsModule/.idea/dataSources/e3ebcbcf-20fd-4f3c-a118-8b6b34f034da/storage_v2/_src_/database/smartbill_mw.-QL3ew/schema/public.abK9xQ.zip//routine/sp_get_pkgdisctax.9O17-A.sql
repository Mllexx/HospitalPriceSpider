create function sp_get_pkgdisctax(fr integer, pkgid integer)
    returns TABLE(taxid integer, pkgcode character varying, packages integer, tax double precision, xtratax double precision)
    language sql
as
$$
SELECT 
taxid,
pkgcode,
packages,
sum(tax) as tax,
sum(xtratax) as xtratax 
FROM
(
SELECT
FTD.TAX AS TAXID,
FTD.TAXRATE,
p.PKGCODE,
p.PACKAGES,
fd.DISTNRM
,fd.DISTXTRA as xtraamt
,((ftd.TAXRATE/100) *fd.DISTNRM) as tax
,((ftd.TAXRATE/100)*fd.DISTXTRA) as xtratax
,(fd.DISTNRM+((ftd.TAXRATE/100) *fd.DISTNRM))  as AMTWTHTAX
,(fd.DISTXTRA+((ftd.TAXRATE/100) *fd.DISTXTRA)) as XTRAAMTWTHTAX
FROM PACKAGES P 
JOIN PACKSERV PS ON P.PACKAGES=PS.PACKAGES
JOIN SERVICES S ON PS.SERVICES = S.SERVICES AND S.ACTIVEITEM=1 AND S.SERVTYPE IN(152,154,157)
JOIN FRRATES F ON F.PACKAGES=p.PACKAGES AND F.RATEEND::date > CURRENT_DATE AND F.ACTIVEITEM=1
JOIN FRDISTR FD ON FD.SERVICES = S.SERVICES AND FD.FRRATES=F.FRRATES
JOIN FRTAXGRPDETAIL FTD ON FD.FRTAXGRP = FTD.FRTAXGRP AND FTD.ISACTIVE=1
WHERE p.ACTIVEITEM=1 and f.FRANCH = fr and p.PACKAGES = pkgid
) AS DD
group by taxid,packages,pkgcode


$$;

alter function sp_get_pkgdisctax(integer, integer) owner to postgres;

