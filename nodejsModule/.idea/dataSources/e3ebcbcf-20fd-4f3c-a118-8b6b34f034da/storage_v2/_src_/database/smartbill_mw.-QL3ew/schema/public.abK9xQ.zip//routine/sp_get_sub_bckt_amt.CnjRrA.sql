create function sp_get_sub_bckt_amt(subid integer)
    returns TABLE(subs integer, franch integer, prepaybucket integer, bcktname character varying, bcktbal double precision, amt numeric, xtraamt numeric, tax numeric, xtratax numeric, amtwthtax numeric, xtraamtwthtax numeric)
    language sql
as
$$
SELECT
SB.SUBS,
f.FRANCH,
p.prepaybucket,
l.ENGLISH as bcktname,
spb.amount as bcktbal,
SUM(distinct fd.DISTNRM) as amt
,SUM(distinct fd.DISTXTRA) as xtraamt
,ROUND(SUM(((ftd.TAXRATE/100) *fd.DISTNRM))::numeric,0) as tax
,ROUND(SUM(((ftd.TAXRATE/100)*fd.DISTXTRA))::numeric,0) as xtratax
,( (SUM(distinct fd.DISTNRM)+ROUND(SUM(((ftd.TAXRATE/100) *fd.DISTNRM))::numeric,0)) ) as AMTWTHTAX
,((SUM(distinct fd.DISTXTRA)+ROUND(SUM(((ftd.TAXRATE/100) *fd.DISTXTRA))::numeric,0)) ) as XTRAAMTWTHTAX
FROM SUBS SB
JOIN subsprepaybucket spb ON sb.subs=spb.SUBS AND spb.ISACTIVE=1
JOIN SUBPKG SP ON SB.SUBS=SP.SUBS AND SP.STARTDATE::date <= CURRENT_DATE AND SP.ENDDATE::date >= CURRENT_DATE
JOIN PACKAGES P ON  SP.PACKAGE = P.PACKAGES
JOIN PACKSERV PS ON P.PACKAGES=PS.PACKAGES
JOIN SERVICES S ON PS.SERVICES = S.SERVICES AND S.ACTIVEITEM=1
JOIN FRRATES F ON F.PACKAGES=p.PACKAGES AND F.RATEEND::date > CURRENT_DATE AND F.ACTIVEITEM=1 AND f.FRANCH = SB.FRANCH
JOIN FRDISTR FD ON FD.SERVICES = S.SERVICES AND FD.FRRATES=F.FRRATES
JOIN FRTAXGRPDETAIL FTD ON FD.FRTAXGRP = FTD.FRTAXGRP AND FTD.ISACTIVE=1
JOIN LISTS L ON spb.PREPAYBUCKET = L.LISTS and L.LISTSGRP = 542
WHERE p.ACTIVEITEM=1
AND SB.SUBS = subid
group by f.franch,SB.SUBS,p.prepaybucket,spb.amount,l.ENGLISH
ORDER BY SB.SUBS

$$;

alter function sp_get_sub_bckt_amt(integer) owner to postgres;

