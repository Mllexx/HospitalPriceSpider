create function sp_get_sub_sched_dsc(subid integer)
    returns TABLE(subs integer, franch integer, subdisc integer, discount integer, discountname character varying, discountcode character varying, discdistrm integer, discdistrschema integer, adddate date, allpkg smallint, firstx integer, everyxth integer, periodtype integer, ptypecode character varying, periodinteger integer, disunits integer, dunittype character varying, prepaybucket integer, bldthrudate date, enddate date, packages integer, subpkg integer, discvaluefirst double precision, discvalueextra double precision)
    language sql
as
$$
select
sd.SUBS,
sd.FRANCH,
sd.SUBDISC,
sd.DISCOUNT,
d.DISCOUNTNAME,
d.DISCOUNTCODE,
d.DISCDISTRM,
d.DISCDISTRSCHEMA,
sd.ADDDATE::date,
sd.ALLPKG,
sd.FIRSTX,
sd.EVERYXTH,
sd.PERIODTYPE,
l.LISTCODE as PTYPECODE,
sd.PERIODINTEGER,
sd.DISCUNITS,
l2.LISTCODE as DUNITTYPE,
sd.PREPAYBUCKET,
sdp.BLDTHRUDATE::date,
sdp.ENDDATE::date,
sdp.PACKAGES,
sdp.SUBPKG,
d.DISCVALUEFIRST,
d.DISCVALUEEXTRA
from subdiscpkg sdp
join subdisc sd on sdp.SUBDISC=sd.SUBDISC
join DISCOUNT d on sd.DISCOUNT=d.DISCOUNT
join LISTS l ON sd.PERIODTYPE=l.LISTS
join LISTS l2 ON sd.DISCUNITS=l2.LISTS
join subpkg sp on sp.SUBPKG=sdp.SUBPKG
where
sdp.BLDTHRUDATE::date >= CURRENT_DATE
AND sd.ADDDATE::date >= CURRENT_DATE
AND sp.BLDTHRUDATE::date  >= CURRENT_DATE
AND sd.subs = subid
order by sd.SUBS,d.DISCOUNT,sdp.SUBPKG


$$;

alter function sp_get_sub_sched_dsc(integer) owner to postgres;

