create function sp_get_pkg_disc_prorate(fr integer, pkgid integer, dp double precision, da double precision, dae double precision)
    returns TABLE(pkgname character varying, franch integer, pkgcode character varying, packages integer, pkgtype integer, discamt numeric, discxtraamt numeric, disctax numeric, discxtratax numeric, discamtwthtax numeric, discxtraamtwthtax numeric)
    language sql
as
$$
SELECT
P.DESCRIP as pkgname,
f.FRANCH,
p.PKGCODE,
p.PACKAGES,
P.PKGTYPE,
CASE
	WHEN s.servtype = 152 THEN  ROUND(ROUND((SUM(distinct da)*dp)::numeric,2),0)
	ELSE ROUND(ROUND((SUM(distinct fd.DISTNRM)*dp)::numeric,2)::numeric,0)
END as discamt,
CASE
	WHEN s.servtype = 152 THEN  ROUND(ROUND((SUM(distinct dae)*dp)::numeric,2)::numeric,0)
	ELSE ROUND(ROUND((SUM(distinct fd.DISTXTRA)*dp)::numeric,2)::numeric,0)
END as discxtraamt,
CASE
	WHEN s.servtype = 152 THEN  SUM(ROUND(((ftd.TAXRATE/100) *da*dp)::numeric,0))
	ELSE SUM(ROUND(((ftd.TAXRATE/100) *fd.DISTNRM*dp)::numeric,0))
END as disctax,
CASE
	WHEN s.servtype = 152 THEN  SUM(ROUND(((ftd.TAXRATE/100)*dae*dp)::numeric,0))
	ELSE SUM(ROUND(((ftd.TAXRATE/100)*fd.DISTXTRA*dp)::numeric,0))
END as discxtratax,
CASE
	WHEN s.servtype = 152 THEN  ROUND(ROUND((SUM(distinct da)*dp)::numeric,2)::numeric,0)+SUM(ROUND(((ftd.TAXRATE/100) *da*dp)::numeric,0))
	ELSE ROUND(ROUND((SUM(distinct fd.DISTNRM)*dp)::numeric,2),0)+SUM(ROUND(((ftd.TAXRATE/100) *fd.DISTNRM*dp)::numeric,0))
END as DISCAMTWTHTAX,
CASE
	WHEN s.servtype = 152 THEN  ROUND(ROUND((SUM(distinct dae)*dp)::numeric,2)::numeric,0)+SUM(ROUND(((ftd.TAXRATE/100) *dae*dp)::numeric,0))
	ELSE ROUND(ROUND((SUM(distinct fd.DISTXTRA)*dp)::numeric,2)::numeric,0)+SUM(ROUND(((ftd.TAXRATE/100) *fd.DISTXTRA*dp)::numeric,0))
END as discxtratax
FROM PACKAGES P
JOIN PACKSERV PS ON P.PACKAGES=PS.PACKAGES
JOIN SERVICES S ON PS.SERVICES = S.SERVICES AND S.ACTIVEITEM=1
JOIN FRRATES F ON F.PACKAGES=p.PACKAGES AND F.RATEEND::date > CURRENT_DATE AND F.ACTIVEITEM=1
JOIN FRDISTR FD ON FD.SERVICES = S.SERVICES AND FD.FRRATES=F.FRRATES
FULL JOIN FRTAXGRPDETAIL FTD ON FD.FRTAXGRP = FTD.FRTAXGRP AND FTD.ISACTIVE=1
WHERE p.ACTIVEITEM=1
and f.FRANCH= fr
and p.PACKAGES= pkgid
group by p.PKGCODE,p.PACKAGES,f.franch,P.DESCRIP,P.PKGTYPE,s.SERVTYPE
ORDER BY P.DESCRIP

$$;

alter function sp_get_pkg_disc_prorate(integer, integer, double precision, double precision, double precision) owner to postgres;

