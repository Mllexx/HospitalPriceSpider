create function sp_get_sub_balance(subid integer)
    returns TABLE(subs integer, listcode character varying, prepaybucket integer, amount double precision)
    language sql
as
$$
SELECT sb.SUBS,l.listcode,sb.PREPAYBUCKET, sb.AMOUNT
FROM SUBSPREPAYBUCKET sb
LEFT JOIN lists l ON L.LISTS=sb.PREPAYBUCKET and l.LISTSGRP=542
WHERE sb.SUBS = subid
$$;

alter function sp_get_sub_balance(integer) owner to postgres;

